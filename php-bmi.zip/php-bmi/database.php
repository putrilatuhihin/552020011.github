<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'bmi_552020011';

// Koneksi ke database
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die('Koneksi database gagal: ' . $conn->connect_error);
}
