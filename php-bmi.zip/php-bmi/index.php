<?php
// tambah file histori-bmi.php untuk tabel histori
include 'histori-bmi.php';
?>

<!DOCTYPE html>
<html>

<head>
    <title>Kalkulator BMI</title>
</head>

<body>
    <h1>Kalkulator BMI</h1>

    <form action="tambah-bmi.php" method="post">

        <table>
            <tr>
                <td><label for="berat">Berat Badan (kg):</label></td>
                <td><input type="text" id="berat" name="berat" required onchange="hitung_bmi()" onkeyup="hitung_bmi()" /></td>
            </tr>
            <tr>
                <td><label for="tinggi">Tinggi Badan (cm):</label></td>
                <td><input type="text" id="tinggi" name="tinggi" required onchange="hitung_bmi()" onkeyup="hitung_bmi()" /></td>
            </tr>
            <tr>
                <td><button type="submit">Simpan BMI Ke Database</button></td>
            </tr>
        </table>
        <input type="text" name="kategori" id="kategori" hidden>
        <input type="text" name="bmi" id="bmi" hidden>
    </form>

    <!-- HASIL -->
    <h2>Hasil:</h2>
    <div id="hasil"></div>

    <br>

    <!-- TABEL HISTORI -->
    <h2>Histori BMI:</h2>
    <table border="1">
        <tr>
            <th>Berat Badan</th>
            <th>Tinggi Badan</th>
            <th>BMI</th>
            <th>Kategori BMI</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['berat'] . "</td>";
                echo "<td>" . $row['tinggi'] . "</td>";
                echo "<td>" . $row['bmi'] . "</td>";
                echo "<td>" . $row['kategori'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr>";
            echo "<td colspan='4'>Tidak ada data BMI</td>";
            echo "</tr>";
        }
        ?>
    </table>

    <script>
        // Fungsi untuk menghitung BMI
        function hitung_bmi() {
            var berat = parseFloat(document.getElementById('berat').value);
            var tinggi = parseFloat(document.getElementById('tinggi').value) / 100; // Konversi tinggi ke meter

            if (berat > 0 && tinggi > 0) {
                var bmi = berat / (tinggi * tinggi);
                var category = "";
                var warna = "";

                if (bmi < 18.5) {
                    category = "Kurus";
                    warna = "blue";
                } else if (bmi >= 18.5 && bmi < 25) {
                    category = "Normal";
                    warna = "green";
                } else if (bmi >= 25 && bmi < 30) {
                    category = "Gemuk";
                    warna = "orange";
                } else {
                    category = "Obesitas";
                    warna = "red";
                }

                document.getElementById('kategori').value = category;
                document.getElementById('bmi').value = bmi.toFixed(2);
                document.getElementById('hasil').style.color = warna;
                document.getElementById('hasil').innerHTML = "BMI Anda: " + bmi.toFixed(2) + " (Kategori: " + category + ")";
            } else {
                document.getElementById('hasil').innerHTML = "Masukkan berat badan dan tinggi badan yang valid.";
                document.getElementById('hasil').style.color = "black";
            }
        }
    </script>
</body>

</html>