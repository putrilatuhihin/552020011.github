<?php
// Koneksi ke database
include 'database.php';

// ambil semua data dari database
$sql = "SELECT * FROM histori_bmi";
$result = $conn->query($sql);

$conn->close();
