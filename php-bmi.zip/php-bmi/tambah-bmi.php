<?php
// Koneksi ke database
include 'database.php';

// Ambil data BMI dari permintaan POST
$berat = $_POST['berat'];
$tinggi = $_POST['tinggi'];
$bmi = $_POST['bmi'];
$kategori = $_POST['kategori'];

// Simpan data BMI ke database
$sql = "INSERT INTO histori_bmi (berat, tinggi, bmi, kategori) VALUES ('$berat', '$tinggi', '$bmi', '$kategori')";
if ($conn->query($sql) === TRUE) {
    header("Location: index.php");
} else {
    header("Location: index.php");
}

$conn->close();
