package Servlet;

import MyPackage.Database;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "EditBarang", urlPatterns = {"/EditBarang"})
public class EditBarang extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        String idBarang = request.getParameter("id_barang");
        String kodeBarang = request.getParameter("kode_barang");
        String namaBarang = request.getParameter("nama_barang");
        String hargaBarang = request.getParameter("harga_barang");
        String satuan = request.getParameter("satuan");
        String keterangan = request.getParameter("keterangan");
        
        Database.editBarang(kodeBarang, namaBarang, hargaBarang, satuan, keterangan, idBarang);
        response.sendRedirect("barang.jsp?status=success");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(EditBarang.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
