package Servlet;

import MyPackage.Database;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Transaksi", urlPatterns = {"/Transaksi"})
public class Transaksi extends HttpServlet {

    protected void processGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            // Mendapatkan nilai-nilai parameter dari request
//            String[] idBarang = request.getParameterValues("id_barang[]");
//            String[] namaBarang = request.getParameterValues("nama_barang[]");
//            String[] hargaBarang = request.getParameterValues("harga_barang[]");
//            String[] quantity = request.getParameterValues("quantity[]");
//            String[] total = request.getParameterValues("total[]");
//
//            HttpSession session = request.getSession();
//
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet Transaksi</title>");
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>ID User : " + session.getAttribute("id_user") + "</h1>");
//
//            // Proses data sesuai kebutuhan Anda
//            // Contoh: Menampilkan data yang diterima
//            for (int i = 0; i < idBarang.length; i++) {
//                out.println("ID Barang: " + idBarang[i] + "<br>");
//                out.println("Nama Barang: " + namaBarang[i] + "<br>");
//                out.println("Harga Barang: " + hargaBarang[i] + "<br>");
//                out.println("Quantity: " + quantity[i] + "<br>");
//                out.println("Total: " + total[i] + "<br><br>");
//            }
//
//            out.println("</body>");
//            out.println("</html>");

        try (PrintWriter out = response.getWriter(); Connection con = Database.initializeDatabase(); PreparedStatement stmt = con.prepareStatement("SELECT u.nama_lengkap, t.jenis, SUM(d.harga_in) AS total "
                + "FROM transaksi t "
                + "JOIN users u ON u.id = t.id_kasir "
                + "JOIN detail_transaksi d ON d.id_transaksi = t.id "
                + "WHERE t.jenis = 'pembelian' AND (DATE(tanggal) BETWEEN '2023-01-01' AND '2023-12-12') "
                + "GROUP BY t.id, u.nama_lengkap, t.jenis "
                + "LIMIT 0, 10")) {

            try (ResultSet rs = stmt.executeQuery()) {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet Transaksi</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>ID User : " + 1 + "</h1>");

                out.println("Nama Kasir\tJenis Transaksi\tTotal");
                out.println("<br>");
                while (rs.next()) {
                    String namaKasir = rs.getString("nama_lengkap");
                    String jenisTransaksi = rs.getString("jenis");
                    double total = rs.getDouble("total");

                    out.println(namaKasir + "\t\t" + jenisTransaksi + "\t\t" + total);
                }

                out.println("</body>");
                out.println("</html>");
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processGet(request, response);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(Transaksi.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // Mendapatkan nilai-nilai parameter dari request
            String[] idBarang = request.getParameterValues("id_barang[]");
            String[] namaBarang = request.getParameterValues("nama_barang[]");
            String[] hargaBarang = request.getParameterValues("harga_barang[]");
            String[] quantity = request.getParameterValues("quantity[]");
            String[] total = request.getParameterValues("total[]");

            HttpSession session = request.getSession();

            Connection con = null;
            PreparedStatement transaksiStmt = null;
            PreparedStatement detailStmt = null;

            try {
                con = Database.initializeDatabase();
                con.setAutoCommit(false); // Mengatur otomatis commit menjadi false untuk transaksi manual

                // Insert ke tabel transaksi
                String transaksiQuery = "INSERT INTO transaksi (tanggal, jenis, id_kasir) VALUES (?, ?, ?)";
                transaksiStmt = con.prepareStatement(transaksiQuery, PreparedStatement.RETURN_GENERATED_KEYS);

                LocalDateTime now = LocalDateTime.now();
                Timestamp timestamp = Timestamp.valueOf(now);

                transaksiStmt.setTimestamp(1, timestamp);
                transaksiStmt.setString(2, "pembelian");
                transaksiStmt.setString(3, (String) session.getAttribute("id_user"));

                transaksiStmt.executeUpdate();

                // Mendapatkan id_transaksi yang baru saja di-generate
                int idTransaksi;
                try (ResultSet generatedKeys = transaksiStmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        idTransaksi = generatedKeys.getInt(1);
                    } else {
                        throw new SQLException("Gagal mendapatkan id transaksi, tidak ada kunci yang dihasilkan.");
                    }
                }

                for (int i = 0; i < idBarang.length; i++) {

                    if (Integer.parseInt(quantity[i]) > 0) {
                        // Insert ke tabel detail_transaksi
                        String detailQuery = "INSERT INTO detail_transaksi (id_transaksi, id_barang, jumlah_in, jumlah_out, harga_in, harga_out, total_in, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                        detailStmt = con.prepareStatement(detailQuery);

                        detailStmt.setInt(1, idTransaksi);
                        detailStmt.setString(2, idBarang[i]);
                        detailStmt.setInt(3, Integer.parseInt(quantity[i])); // jumlah_in
                        detailStmt.setInt(4, 0); // jumlah_out
                        detailStmt.setDouble(5, Double.parseDouble(hargaBarang[i]));
                        detailStmt.setDouble(6, 0); // harga_out
                        detailStmt.setDouble(7, Double.parseDouble(total[i])); // total_in
                        detailStmt.setTimestamp(8, timestamp);

                        detailStmt.executeUpdate();
                    }
                }

                con.commit(); // Commit transaksi jika berhasil

            } catch (SQLException | ClassNotFoundException ex) {
                if (con != null) {
                    con.rollback(); // Rollback transaksi jika terjadi kesalahan
                }
                throw ex; // Melempar exception untuk penanganan lebih lanjut
            } finally {
                // Menutup statement dan koneksi
                if (detailStmt != null) {
                    detailStmt.close();
                }
                if (transaksiStmt != null) {
                    transaksiStmt.close();
                }
                if (con != null) {
                    con.setAutoCommit(true); // Mengatur otomatis commit menjadi true kembali
                    con.close();
                }
            }

            response.sendRedirect("pembelian.jsp?status=success");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);

        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(Transaksi.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

}
