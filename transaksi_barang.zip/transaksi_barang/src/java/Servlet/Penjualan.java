package Servlet;

import MyPackage.Database;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Penjualan", urlPatterns = {"/Penjualan"})
public class Penjualan extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // Mendapatkan nilai-nilai parameter dari request
            String[] idBarang = request.getParameterValues("id_barang[]");
            String[] namaBarang = request.getParameterValues("nama_barang[]");
            String[] hargaBarang = request.getParameterValues("harga_barang[]");
            String[] quantity = request.getParameterValues("quantity[]");
            String[] total = request.getParameterValues("total[]");

            HttpSession session = request.getSession();

            Connection con = null;
            PreparedStatement transaksiStmt = null;
            PreparedStatement detailStmt = null;

            try {
                con = Database.initializeDatabase();
                con.setAutoCommit(false); // Mengatur otomatis commit menjadi false untuk transaksi manual

                // Insert ke tabel transaksi
                String transaksiQuery = "INSERT INTO transaksi (tanggal, jenis, id_kasir) VALUES (?, ?, ?)";
                transaksiStmt = con.prepareStatement(transaksiQuery, PreparedStatement.RETURN_GENERATED_KEYS);

                LocalDateTime now = LocalDateTime.now();
                Timestamp timestamp = Timestamp.valueOf(now);

                transaksiStmt.setTimestamp(1, timestamp);
                transaksiStmt.setString(2, "penjualan");
                transaksiStmt.setString(3, (String) session.getAttribute("id_user"));

                transaksiStmt.executeUpdate();

                // Mendapatkan id_transaksi yang baru saja di-generate
                int idTransaksi;
                try (ResultSet generatedKeys = transaksiStmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        idTransaksi = generatedKeys.getInt(1);
                    } else {
                        throw new SQLException("Gagal mendapatkan id transaksi, tidak ada kunci yang dihasilkan.");
                    }
                }

                for (int i = 0; i < idBarang.length; i++) {

                    if (Integer.parseInt(quantity[i]) > 0) {
                        // Insert ke tabel detail_transaksi
                        String detailQuery = "INSERT INTO detail_transaksi (id_transaksi, id_barang, jumlah_in, jumlah_out, harga_in, harga_out, total_out, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                        detailStmt = con.prepareStatement(detailQuery);

                        detailStmt.setInt(1, idTransaksi);
                        detailStmt.setString(2, idBarang[i]);
                        detailStmt.setInt(3, 0); // jumlah_in
                        detailStmt.setInt(4, Integer.parseInt(quantity[i])); // jumlah_out
                        detailStmt.setDouble(5, 0);
                        detailStmt.setDouble(6, Double.parseDouble(hargaBarang[i])); // harga_out
                        detailStmt.setDouble(7, Double.parseDouble(total[i])); // total_out
                        detailStmt.setTimestamp(8, timestamp);

                        detailStmt.executeUpdate();
                    }
                }

                con.commit(); // Commit transaksi jika berhasil

            } catch (SQLException | ClassNotFoundException ex) {
                if (con != null) {
                    con.rollback(); // Rollback transaksi jika terjadi kesalahan
                }
                throw ex; // Melempar exception untuk penanganan lebih lanjut
            } finally {
                // Menutup statement dan koneksi
                if (detailStmt != null) {
                    detailStmt.close();
                }
                if (transaksiStmt != null) {
                    transaksiStmt.close();
                }
                if (con != null) {
                    con.setAutoCommit(true); // Mengatur otomatis commit menjadi true kembali
                    con.close();
                }
            }

            response.sendRedirect("penjualan.jsp?status=success");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);

        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(Penjualan.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

}
