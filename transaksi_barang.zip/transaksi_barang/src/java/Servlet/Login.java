package Servlet;

import MyPackage.Database;
import MyPackage.Password;
import static MyPackage.Password.encryptPassword;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Login", urlPatterns = {"/Login"})
public class Login extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String password = "1234";
        String encryptedPassword = encryptPassword(password);
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Login</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Bcrypt : " + encryptedPassword + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processLogin(request, response);
    }

    protected void processLogin(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            // Menyiapkan query dengan parameter username
            try (
                    Connection con = Database.initializeDatabase(); // Menyiapkan query dengan parameter username
                     PreparedStatement st = con.prepareStatement("SELECT * FROM users WHERE username = ?")) {
                st.setString(1, request.getParameter("username"));

                // Eksekusi query
                ResultSet rs = st.executeQuery();

                // Periksa apakah pengguna ditemukan
                if (rs.next()) {
                    // Pengguna ditemukan, periksa password
                    String storedPassword = rs.getString("password");
                    String inputPassword = request.getParameter("password");
                    boolean isMatch = Password.verifyPassword(inputPassword, storedPassword);

                    if (isMatch) {
                        // Password cocok, buat sesi
                        HttpSession session = request.getSession();
                        session.setAttribute("id_user", rs.getString("id"));
                        session.setAttribute("username", request.getParameter("username"));

                        // Redirect ke halaman setelah login sukses
                        response.sendRedirect("barang.jsp?status=success");
                    } else {
                        // Password tidak cocok, tampilkan pesan kesalahan
                        response.sendRedirect("index.jsp?status=failed");
                    }
                } else {
                    // Pengguna tidak ditemukan, tampilkan pesan kesalahan
                    response.sendRedirect("index.jsp?status=userNotFound");
                }
                // Tutup koneksi
                rs.close();
            }
        } catch (IOException | ClassNotFoundException | NumberFormatException | SQLException e) {
            PrintWriter out = response.getWriter();
            out.println("<html>"
                    + "<body>"
                    + "<b>" + e.getMessage() + "</b>"
                    + "</body>"
                    + "</html>");
        }
    }
}
