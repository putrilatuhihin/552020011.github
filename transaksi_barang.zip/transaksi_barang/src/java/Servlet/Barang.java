package Servlet;

import MyPackage.Database;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "Barang", urlPatterns = {"/Barang"})
public class Barang extends HttpServlet {

    protected void processPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        boolean success = false;
        try {
            String kodeBarang = request.getParameter("kode_barang");
            String namaBarang = request.getParameter("nama_barang");
            String hargaBarang = request.getParameter("harga_barang");
            String satuan = request.getParameter("satuan");
            String keterangan = request.getParameter("keterangan");

            Database.insertBarang(kodeBarang, namaBarang, hargaBarang, satuan, keterangan);
            success = true;
            System.out.println("Data berhasil dimasukkan ke database.");
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("Terjadi kesalahan saat memasukkan data ke database: " + e.getMessage());
        }

        // Mengatur parameter status sesuai hasil permintaan POST
        String redirectURL = "barang.jsp";
        if (success) {
            redirectURL += "?status=success";
        } else {
            redirectURL += "?status=failed";
        }

        // Melakukan redirect ke halaman berikutnya dengan parameter status
        response.sendRedirect(redirectURL);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processPost(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        checkIfKodeBarangAndNamaBarangExist(request, response);
    }

    // RETURN JSON
    protected void checkIfKodeBarangAndNamaBarangExist(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        boolean exist = false;

        try {
            int hasId = Integer.parseInt(request.getParameter("has_id"));
            String kodeBarang = request.getParameter("kode_barang");
            String namaBarang = request.getParameter("nama_barang");

            if (hasId != 0) {
                if (Database.checkIfKodeBarangAndNamaBarangExist(kodeBarang, namaBarang, hasId)) {
                    exist = true;
                };
            } else {
                if (Database.checkIfKodeBarangAndNamaBarangExist(kodeBarang, namaBarang)) {
                    exist = true;
                };
            }
            Gson gson = new Gson();
            String json = gson.toJson(exist);
            response.getWriter().write(json);
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("Terjadi kesalahan saat memasukkan data ke database: " + e.getMessage());
        }
    }
}
