package MyPackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

final public class Database {

    public static Connection initializeDatabase()
            throws SQLException, ClassNotFoundException {
        String dbDriver = "org.mariadb.jdbc.Driver";
        String dbURL = "jdbc:mariadb:// localhost:3306/";
        String dbName = "transaksi_barang";
        String dbUsername = "root";
        String dbPassword = "";

        Class.forName(dbDriver);
        Connection con = DriverManager.getConnection(dbURL + dbName,
                dbUsername,
                dbPassword);
        return con;
    }

    public static boolean checkIfKodeBarangAndNamaBarangExist(String kodeBarang, String namaBarang) throws SQLException, ClassNotFoundException {
        boolean exist = false;
        try (Connection con = Database.initializeDatabase()) {
            PreparedStatement st = con.prepareStatement("SELECT * FROM barang WHERE kode_barang = ? OR nama_barang = ?");
            st.setString(1, kodeBarang);
            st.setString(2, namaBarang);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                exist = true;
            }
        }
        return exist;
    }
    
    public static boolean checkIfKodeBarangAndNamaBarangExist(String kodeBarang, String namaBarang, int id) throws SQLException, ClassNotFoundException {
    boolean exist = false;
    try (Connection con = Database.initializeDatabase()) {
        PreparedStatement st = con.prepareStatement("SELECT * FROM barang WHERE (kode_barang = ? OR nama_barang = ?) AND id <> ?");
        st.setString(1, kodeBarang);
        st.setString(2, namaBarang);
        st.setInt(3, id);
        ResultSet rs = st.executeQuery();
        if (rs.next()) {
            exist = true;
        }
    }
    return exist;
}

    public static void insertBarang(String kodeBarang, String namaBarang, String hargaBarang, String satuan, String keterangan)
            throws SQLException, ClassNotFoundException {
        try (Connection con = initializeDatabase()) {
            String query = "INSERT INTO barang (kode_barang, nama_barang, harga_barang, satuan, keterangan) VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setString(1, kodeBarang);
                stmt.setString(2, namaBarang);
                stmt.setString(3, hargaBarang);
                stmt.setString(4, satuan);
                stmt.setString(5, keterangan);

                stmt.executeUpdate();
            }
        }
    }

    public static void editBarang(
            String kodeBarang,
            String namaBarang,
            String hargaBarang,
            String satuan,
            String keterangan,
            String idBarang
    )
            throws SQLException, ClassNotFoundException {
        try (Connection con = initializeDatabase()) {
            String query = "UPDATE barang "
                    + "SET kode_barang = ?, "
                    + "nama_barang = ?, "
                    + "harga_barang = ?, "
                    + "satuan = ?, "
                    + "keterangan = ? "
                    + "WHERE id = ?";

            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setString(1, kodeBarang);
                stmt.setString(2, namaBarang);
                stmt.setString(3, hargaBarang);
                stmt.setString(4, satuan);
                stmt.setString(5, keterangan);
                stmt.setString(6, idBarang);

                stmt.executeUpdate();
            }
        }
    }

    public static void deleteBarang(String idBarang)
            throws SQLException, ClassNotFoundException {
        try (Connection con = initializeDatabase()) {
            String query = "DELETE FROM barang WHERE id = ?";

            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setString(1, idBarang);

                stmt.executeUpdate();
            }
        }
    }

    public static int getTotalItemsFromDatabase(String tableName) throws SQLException, ClassNotFoundException {
        int totalItems = 0;

        try (Connection con = Database.initializeDatabase(); PreparedStatement st = con.prepareStatement("SELECT COUNT(*) AS total FROM " + tableName); ResultSet rs = st.executeQuery()) {
            if (rs.next()) {
                totalItems = rs.getInt("total");
            }
        }

        return totalItems;
    }
    
    public static int getTotalItemsFromDatabase(String tableName, String tanggalAwal, String tanggalAkhir, String fieldTanggal) throws SQLException, ClassNotFoundException {
        int totalItems = 0;

        try (Connection con = Database.initializeDatabase(); 
                PreparedStatement st = con.prepareStatement("SELECT COUNT(*) AS total FROM " + tableName + " WHERE DATE(" + fieldTanggal + ") BETWEEN '" + tanggalAwal + "' AND '" + tanggalAkhir + "'");
                ResultSet rs = st.executeQuery()) {
            if (rs.next()) {
                totalItems = rs.getInt("total");
            }
        }

        return totalItems;
    }
}
