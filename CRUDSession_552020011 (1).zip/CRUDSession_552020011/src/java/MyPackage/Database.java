package MyPackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

final public class Database {
    public static Connection initializeDatabase()
            throws SQLException, ClassNotFoundException {
        String dbDriver = "org.mariadb.jdbc.Driver";
        String dbURL = "jdbc:mariadb:// localhost:3306/";
        String dbName = "session_552020011";
        String dbUsername = "root";
        String dbPassword = "";

        Class.forName(dbDriver);
        Connection con = DriverManager.getConnection(dbURL + dbName,
                dbUsername,
                dbPassword);
        return con;
    }
}
