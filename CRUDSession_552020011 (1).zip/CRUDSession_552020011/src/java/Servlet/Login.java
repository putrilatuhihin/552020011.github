package Servlet;

import MyPackage.Database;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Login", urlPatterns = {"/Login"})
public class Login extends HttpServlet {

    protected void processGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processGet(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processPost(request, response);
    }

    protected void processPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Connection con = Database.initializeDatabase();

            // Menyiapkan query dengan parameter username
            PreparedStatement st = con.prepareStatement("SELECT * FROM user WHERE username = ?");
            st.setString(1, request.getParameter("username"));

            // Eksekusi query
            ResultSet rs = st.executeQuery();

            // Periksa apakah pengguna ditemukan
            if (rs.next()) {
                // Pengguna ditemukan, periksa password
                String passwordFromDB = rs.getString("password");
                if (passwordFromDB.equals(request.getParameter("password"))) {
                    // Password cocok, buat sesi
                    HttpSession session = request.getSession();
                    session.setAttribute("username", request.getParameter("username"));

                    // Redirect ke halaman setelah login sukses
                    response.sendRedirect("dashboard.jsp?success=true");
                } else {
                    // Password tidak cocok, tampilkan pesan kesalahan
                    response.sendRedirect("index.jsp?error=invalid");
                }
            } else {
                // Pengguna tidak ditemukan, tampilkan pesan kesalahan
                response.sendRedirect("index.jsp?error=notfound");
            }
            // Tutup koneksi
            rs.close();
            st.close();
            con.close();
        } catch (IOException | ClassNotFoundException | NumberFormatException | SQLException e) {
            PrintWriter out = response.getWriter();
            out.println("<html>"
                    + "<body>"
                    + "<b>" + e.getMessage() + "</b>"
                    + "</body>"
                    + "</html>");
        }

    }

}
