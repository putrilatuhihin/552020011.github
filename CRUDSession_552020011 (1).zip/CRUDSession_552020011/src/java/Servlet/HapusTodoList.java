package Servlet;

import MyPackage.Database;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "HapusTodoList", urlPatterns = {"/HapusTodoList"})
public class HapusTodoList extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Buat koneksi dengan database
            Connection con = Database.initializeDatabase();

            // menyiapkan query
            PreparedStatement st = con
                    .prepareStatement("DELETE FROM todolist WHERE id = ?");

            st.setString(1, request.getParameter("idhapus"));

            // eksekusi query
            st.executeUpdate();

            // tutup semua koneksi
            st.close();
            con.close();

            response.sendRedirect("dashboard.jsp?delete=success");
        } catch (IOException | ClassNotFoundException | NumberFormatException | SQLException e) {
            response.sendRedirect("dashboard.jsp?delete=failed");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

}
