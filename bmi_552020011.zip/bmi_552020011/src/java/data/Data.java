package data;
public final class Data {
    private int id;
    private Float tinggi;
    private Float berat;
    private Float bmi;
    private String kategori;

    public Data(int id, Float tinggi, Float berat, Float bmi, String kategori) {
        setId(id);
        setTinggi(tinggi);
        setBerat(berat);
        setBmi(bmi);
        setKategori(kategori);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Float getTinggi() {
        return tinggi;
    }

    public void setTinggi(Float tinggi) {
        this.tinggi = tinggi;
    }

    public Float getBerat() {
        return berat;
    }

    public void setBerat(Float berat) {
        this.berat = berat;
    }

    public Float getBmi() {
        return bmi;
    }

    public void setBmi(Float bmi) {
        this.bmi = bmi;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }
}