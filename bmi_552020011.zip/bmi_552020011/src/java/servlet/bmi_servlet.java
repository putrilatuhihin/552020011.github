package servlet;

import data.Data;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.Koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.sql.ResultSet;
import java.util.ArrayList;

@WebServlet(name = "bmi_servlet", urlPatterns = {"/bmi_servlet"})
public class bmi_servlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet bmi_servlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet bmi_servlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        inputDatabase(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    public static List<Data> getDataFromDatabase() throws ClassNotFoundException {
        List<Data> dataList = new ArrayList<>();

        try {
            Connection con = Koneksi.initializeDatabase();

            // menyiapkan query
            PreparedStatement st = con
                    .prepareStatement("SELECT * FROM histori_bmi");
            
            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                Float tinggi = rs.getFloat("tinggi");
                Float berat = rs.getFloat("berat");
                Float bmi = rs.getFloat("bmi");
                String kategori = rs.getString("kategori");
                // Ambil kolom lainnya sesuai dengan struktur tabel

                Data data = new Data(id, tinggi, berat, bmi, kategori);
                dataList.add(data);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return dataList;
    }

    protected void inputDatabase(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            // Buat koneksi dengan database
            Connection con = Koneksi.initializeDatabase();

            // menyiapkan query
            PreparedStatement st = con
                    .prepareStatement("INSERT INTO histori_bmi (berat, tinggi, bmi, kategori) values(?, ?, ?, ?)");

            st.setFloat(1, Float.parseFloat(request.getParameter("berat")));
            st.setFloat(2, Float.parseFloat(request.getParameter("tinggi")));
            st.setFloat(3, Float.parseFloat(request.getParameter("bmi")));
            st.setString(4, request.getParameter("kategori"));

            // eksekusi query
            st.executeUpdate();
 
           // tutup semua koneksi
            st.close();
            con.close();

            // tampilkan pesan sukses
            PrintWriter out = response.getWriter();
            out.println("<html>"
                    + "<body>"
                    + "<h1>Berhasil ditambah ke database</h1>"
                    + "<br>"
                    + "<a href='bmi.jsp'>Kembali Ke Kalkulator BMI</a>"
                    + "</body>"
                    + "</html>");
        } catch (IOException | ClassNotFoundException | NumberFormatException | SQLException e) {
            PrintWriter out = response.getWriter();
            out.println("<html>"
                    + "<body>"
                    + "<b>" + e.getMessage() + "</b>"
                    + "</body>"
                    + "</html>");
        }

    }

}
